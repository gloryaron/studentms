package com.example.config_client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@SpringBootApplication
@RefreshScope
@RestController
public class ConfigClientApplication {

	@Value("${my-property}")
	private String myProperty;
	@Value("${your-property}")
	private String yourProperty;
	@Value("${common.property}")
	private String commonProperty;
	@Value("${paymentPassword}")
	private String paymentPassword;


	@GetMapping("/properties")
	public Map<String, String> getProperties() {
		Map<String, String> properties = new HashMap<>();
		properties.put("myProperty", myProperty);
		properties.put("yourProperty", yourProperty);
		properties.put("commonProperty", commonProperty);
		properties.put("paymentPassword", paymentPassword);

		return properties;
	}

	public static void main(String[] args) {
		SpringApplication.run(ConfigClientApplication.class, args);
	}

}
