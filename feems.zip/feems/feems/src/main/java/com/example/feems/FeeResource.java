package com.example.feems;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping ("/fees")
public class FeeResource {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FeeResource.class);
	
	@Autowired
	private FeeRepo repo;
	
	@GetMapping
	public List<Fee> getFeesPaid(){
		
		LOGGER.info("Getting all users from Database");
		return repo.findAll();
		
	}
	
	@PostMapping("/pay")
	public ResponseEntity<Fee> updateFee(@RequestBody Fee feeDetails){
		LOGGER.info("Updating fee details for student with with id {}",feeDetails.getId());
		
		Optional<Fee> studentfound = repo.findById(feeDetails.getId());
		if(studentfound.isEmpty()) {
			LOGGER.error("user id not found {}",feeDetails.getId());
			return ResponseEntity.notFound().build();
		}
		Fee updatedFee = null;
		updatedFee = repo.save(feeDetails);	
		LOGGER.info("updated fee details to database with id{}",feeDetails.getId());	
		return ResponseEntity.created(URI.create((feeDetails.getName()))).body(updatedFee);
			
	}

}
