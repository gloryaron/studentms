INSERT INTO fee_details (ID, NAME, feepaid, AMOUNT) VALUES (1, 'John', true, 800),(2, 'Jane', true, 800);



