package com.example.feems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
