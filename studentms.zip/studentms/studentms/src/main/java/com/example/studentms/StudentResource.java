package com.example.studentms;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.feems.Fee;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import reactor.core.publisher.Mono;


@RestController
@RequestMapping ("/student")
public class StudentResource {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(StudentResource.class);
	
	@Autowired
	private StudentRepo repo;
	
	@Autowired
    private WebClient webClient; //load-balanced
	
	@GetMapping("/getList")
	public List<Student> getAllUsers(){
		
		LOGGER.info("Getting all users from Database");
		return repo.findAll();
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Student> getStudentFromID(@PathVariable Integer id){
		
		LOGGER.info("Getting single student from database with id {}",id);
		
		Optional<Student> studentfound = repo.findById(id);
		if(studentfound.isEmpty()) {
			LOGGER.error("user id not found {}",id);
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(studentfound.get());
	}
	
	@PostMapping("/create")
	public ResponseEntity<Student> addStudent(@RequestBody Student student){
		LOGGER.info("adding student to database");
		Student savedStudent = repo.save(student);
		LOGGER.info("added student to database with id{}",savedStudent.getId());	
		return ResponseEntity.created(URI.create(student.getName())).body(savedStudent);
			
	}
	
	@GetMapping("/delete/{id}")
	public ResponseEntity<?> deleteStudentById(@PathVariable Integer id){
		LOGGER.info("Deleting single student from database with id {}",id);
		
		Optional<Student> studentfound = repo.findById(id);
		if(studentfound.isEmpty()) {
			LOGGER.error("user id not found {}",id);
			return (ResponseEntity.status(404).body("{\"error\": \"Student Not Found\""));
		}
		repo.deleteById(id);
		return ResponseEntity.ok().body("{\"message\": \"Student Deleted\"}");
				
		
	}
	
	@PostMapping("/update")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student){
		LOGGER.info("Updating student from database with id {}",student.getId());
		
		Optional<Student> studentfound = repo.findById(student.getId());
		if(studentfound.isEmpty()) {
			LOGGER.error("user id not found {}",student.getId());
			return ResponseEntity.notFound().build();
		}
		Student updatedStudent = null;
		updatedStudent = repo.save(student);	
		LOGGER.info("updated student to database with id{}",student.getId());	
		return ResponseEntity.created(URI.create((student.getName()))).body(updatedStudent);
			
	}
	
	
	 @GetMapping("/client-fees")
	 @CircuitBreaker(name = "feemsclient", fallbackMethod = "feemsfallback")
	 public Object getFeeFromFeems() { 
		 return webClient.get().uri("/fees").retrieve().bodyToMono(Object.class); 
		 }
	  
		
	 @PostMapping("/client-fees-pay")
	 @CircuitBreaker(name = "feemsclient", fallbackMethod = "feemsfallback")
	 public Mono<Fee> payFeeFromFeems(@RequestBody Fee feeDetails) {
		 return webClient.post().uri("/fees/pay").bodyValue(feeDetails).retrieve().bodyToMono(Fee.class); 
		 }
		  
		
	 private Mono feemsfallback(CallNotPermittedException ex) {
		 System.out.println("Fallback is invoked"); return Mono.just(new String[]{"x",
				 "y", "z"}); }
	 
	
}
