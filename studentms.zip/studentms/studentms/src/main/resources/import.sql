INSERT INTO student_details (ID, NAME, GRADE, DOB, ADDRESS) VALUES (1, 'John', '8', '12-06-2016', 'Street 1, Coimbatore'),(2, 'Jane', '8', '13-06-2016', 'KK Street, Coimbatore');



